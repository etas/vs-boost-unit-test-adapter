// stdafx.cpp : source file that includes just the standard includes
// Boost Unit Test Project.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#define BOOST_TEST_MODULE $safeprojectname$

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
