      
#include "stdafx.h"

BOOST_AUTO_TEST_CASE( $safeitemname$ )  
{
     // TODO: Your test code here
}

